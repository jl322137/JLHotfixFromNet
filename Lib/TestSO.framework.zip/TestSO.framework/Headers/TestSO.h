//
//  TestSO.h
//  TestSO
//
//  Created by Aimy on 4/28/15.
//  Copyright (c) 2015 aimy. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TestSO.
FOUNDATION_EXPORT double TestSOVersionNumber;

//! Project version string for TestSO.
FOUNDATION_EXPORT const unsigned char TestSOVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestSO/PublicHeader.h>


